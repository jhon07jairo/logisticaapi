CREATE DATABASE DBAPI;
USE DBAPI;

CREATE TABLE CLIENTE(
IdCliente int primary key identity (1,1),
Nombre varchar (50)
);

CREATE TABLE TIPOPRODUCTO(
IdTipoProducto int primary key identity (1,1),
Descripcion varchar (50)
);

CREATE TABLE BODEGA(
IdBodega int primary key identity (1,1),
Nombre varchar (50),
Direccion varchar (100),
Capacidad int
);

CREATE TABLE PUERTO(
IdPuerto int primary key identity (1,1),
Nombre varchar (50),
Direccion varchar (100),
Capacidad int
);

CREATE TABLE ENVIOTERRESTRE(
IdEnvio int primary key identity (1,1),
IdCliente int,
IdProducto int,
Cantidad int,
FechaRegistro date,
FechaEntrega date,
IdBodega int,
PrecioEnvio decimal (10,2),
PrecioDescuento decimal (10,2),
PlacaVehiculo varchar (10),
NumeroGuia varchar (10),
CONSTRAINT FK_IDCLIENTE FOREIGN KEY (IdCliente) REFERENCES CLIENTE(IdCliente),
CONSTRAINT FK_IDPRODUCTOID FOREIGN KEY (IdProducto) REFERENCES PRODUCTO(IdProducto),
CONSTRAINT FK_IDBODEGA FOREIGN KEY (IdBodega) REFERENCES BODEGA(IdBodega)
);

CREATE TABLE ENVIOMARITIMO(
IdEnvio int primary key identity (1,1),
IdCliente int,
IdProducto int,
Cantidad int,
FechaRegistro date,
FechaEntrega date,
IdPuerto int,
PrecioEnvio decimal (10,2),
PrecioDescuento decimal (10,2),
NumeroFlota varchar (8),
NumeroGuia varchar (10),
CONSTRAINT FK_IDCLIENTEID FOREIGN KEY (IdCliente) REFERENCES CLIENTE(IdCliente),
CONSTRAINT FK_IDPRODUCTO FOREIGN KEY (IdProducto) REFERENCES PRODUCTO(IdProducto),
CONSTRAINT FK_IDPUERTO FOREIGN KEY (IdPuerto) REFERENCES PUERTO(IdPuerto)
);

CREATE TABLE PRODUCTO(
IdProducto int primary key identity (1,1),
IdTipoProducto int, 
Nombre varchar (50),
Precio decimal (10,2),
CONSTRAINT FK_IDPRODUCTID FOREIGN KEY (IdTipoProducto) REFERENCES TIPOPRODUCTO(IdTipoProducto)
);

INSERT INTO PRODUCTO (IdTipoProducto, Nombre, Precio) VALUES
(1,'Producto A', 10000),(2,'Producto B', 9000);

INSERT INTO TIPOPRODUCTO (Descripcion) VALUES
('Terrestre'),('Maritimo');

INSERT INTO CLIENTE (Nombre) VALUES
('Cliente Terrestre'),('Cliente Maritimo');

INSERT INTO BODEGA(Nombre,Direccion,Capacidad) VALUES
('Bodega A','Norte',90),('Bodega B','Sur',80);

INSERT INTO PUERTO(Nombre,Direccion,Capacidad) VALUES
('Puerto A','Norte',95),('Puerto B','Sur',85);

SELECT * FROM TIPOPRODUCTO;
SELECT * FROM CLIENTE;
SELECT * FROM BODEGA;
SELECT * FROM PUERTO;
SELECT * FROM PRODUCTO;
SELECT * FROM ENVIOTERRESTRE;
SELECT * FROM ENVIOMARITIMO;

